# Privacy Policy

Your privacy is my priority. This browser extension is designed with your security in mind and does not collect, store, or share any personal data. I respect your privacy fully and ensure that no information is gathered or used in any way.

If you have any questions or concerns, feel free to reach out to me at [avishaigonen@gmail.com](mailto:avishaigonen@gmail.com). I'm here to help!
